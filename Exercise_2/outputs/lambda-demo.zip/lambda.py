import os


def hello(event, context):
    print("\n")
    print("Welcome To Lambda Demo Lab with Terraform!")
    print("Woah I'm getting a hang on this")
    print("\n")